let containerEl = document.getElementById("speedTypingTest")
let timerEl = document.getElementById("timer")
let quoteEl = document.getElementById("quoteDisplay")
let resultEl = document.getElementById("result")
let inputEl = document.getElementById("quoteInput")
let submitEl = document.getElementById("submitBtn")
let resetEl = document.getElementById("resetBtn")
let loading = document.getElementById("spinner")

function getQuote() {
    resultEl.textContent = ""
    timerEl.textContent = 0
    let options = {
        method: "GET"
    }
    loading.classList.remove("d-none")
    quoteEl.classList.toggle("d-none")
    fetch("https://apis.ccbp.in/random-quote", options)
        .then(function(response) {
            return response.json()
        })
        .then(function(jsonData) {
            loading.classList.add("d-none")
            quoteEl.classList.toggle("d-none")
            quoteEl.textContent = jsonData.content
        })
    let counter = 0
    let uniqueId = setInterval(function() {
        counter = counter + 1
        timerEl.textContent = counter
    }, 1000)

    submitEl.onclick = function() {
        let inputV = inputEl.value
        let quote = quoteEl.textContent
        if (inputV === quote) {
            clearInterval(uniqueId)
            resultEl.textContent = "You typed in " + counter + " sentence"
        } else {
            resultEl.textContent = "You typed incorrect sentence"
        }
    }
    resetEl.onclick = function() {
        clearInterval(uniqueId)
        timerEl.textContent = 0
        inputEl.value = ""
        getQuote()
    }
}

function process() {
    getQuote()
}
process()